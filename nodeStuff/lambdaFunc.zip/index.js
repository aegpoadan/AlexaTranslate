let Alexa = require('alexa-sdk');
let translate = require('google-translate-api');
let AWS = require('aws-sdk');
AWS.config.update({accessKeyId: "AKIAJYJCD7XEQEWWWOFA", secretAccessKey: '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'});
const fs = require('fs')
const dictionaries = require('./dictionaries.js');
const s3baseURL = 'https://translate-audio.s3.amazonaws.com/';
const bucket = 'translate-audio';

const Polly = new AWS.Polly({
    signatureVersion: 'v4',
    region: 'us-east-1',
});

function languageToCode(language) {
	return dictionaries.languageCodeDictionary[language];
}

function getVoiceActor(language) {
	var supportedLanguage = dictionaries.translatorVoices[language];
	if(supportedLanguage) {
		return supportedLanguage[0];
	} else {
		return dictionaries.translatorVoices["English"][1];
	}
}

function putObjectToS3(bucket, key, data){
    var s3 = new AWS.S3();
    var params = {
        Bucket : bucket,
        Key : key,
        Body : data
    }
    s3.putObject(params, function(err, data) {
      if (err) {
      	console.log(err, err.stack);
    	} else {
    		console.log("The file was successfully uploaded to S3!");
  		}          
    });
}

function translateText(language, text) {
		const languageCode = languageToCode(language);
		if(!languageCode) {
			console.error("Unsupported language specified!");
			return "Unsupported language specified!";
		}
		const voiceActor = getVoiceActor(language);

		translate(text, {to: languageCode}).then(res => {
			function textToSpeech(text) {
				let params = {
			    'Text': text,
			    'OutputFormat': 'mp3',
			    'VoiceId': 'Conchita',
				};

				Polly.synthesizeSpeech(params, (err, data) => {
			    if (err) {
			        console.log(err.code)
			    } else if (data) {
			        if (data.AudioStream instanceof Buffer) {
			        		//Can't write to AWS Lambda
			            /*fs.writeFile("./speech.mp3", data.AudioStream, function(err) {
			                if (err) {
			                    return console.log(err)
			                }
			                console.log("The file was saved!")
			            });*/

			            putObjectToS3(bucket, 'speechTranslated.mp3', data.AudioStream);
			            console.log(s3baseURL + 'speechTranslated.mp3');
			        }
			    }
				});
			};

			textToSpeech(res.text);
		}).catch(err => {
    	console.error(err);
		});
};

let handlers = {
    'Translate': function () {
    		var language = this.event.request.intent.slots.Language.value;
    		var text = this.event.request.intent.slots.Text.value;

    		translateText(language, text);
    }
};

exports.handler = (event, context, callback) => {
		var alexa = Alexa.handler(event, context, callback);
		alexa.registerHandlers(handlers);
		alexa.execute();

    callback(null, 'Success!');
};

translateText("Spanish", "I love bread in the morning");